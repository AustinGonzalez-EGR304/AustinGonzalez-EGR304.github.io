#include <xc.h>
#include <stdint.h>
#include "mcc_generated_files/system/system.h"

#ifndef _XTAL_FREQ
#define _XTAL_FREQ 64000000UL   
#endif

// --------------------------------------------------
// GPIO assignments
// --------------------------------------------------
static void IO_Init(void)
{
    // Disable analog
    ANSELD = 0x00;       // RD7 digital
    ANSELA = 0x00;       // all PORTA digital 
    ANSELF = 0x00;       // RF0, RF2, RF4 digital
    ANSELC = 0x00;       // RC7 digital

    // Directions
    TRISDbits.TRISD7 = 1;   // RD7 = BUTTON INPUT 
    TRISAbits.TRISA3 = 0;   // RA3 output 
    TRISFbits.TRISF2 = 0;   // RF2 output
    TRISFbits.TRISF0 = 0;   // RF0 output
    TRISCbits.TRISC7 = 0;   // RC7 output
    TRISAbits.TRISA4 = 0;   // RA4 output 
    TRISFbits.TRISF4 = 0;   // RF4 output 

    // Initial output states
    LATAbits.LATA3 = 0;
    LATFbits.LATF2 = 0;
    LATFbits.LATF0 = 0;
    LATCbits.LATC7 = 0;
    LATAbits.LATA4 = 0;
    LATFbits.LATF4 = 0;
}

// --------------------------------------------------
// Sequence Function
// --------------------------------------------------
static void MotorSequence(void)
{
    // RA3 ON (full cycle)
    LATAbits.LATA3 = 1;

    // RF2 HIGH for 1 sec
    LATFbits.LATF2 = 1;
    __delay_ms(1000);
    LATFbits.LATF2 = 0;

    // RF0 HIGH for 1 sec
    LATFbits.LATF0 = 1;
    __delay_ms(1000);
    LATFbits.LATF0 = 0;

    // RC7 HIGH for 1 sec
    LATCbits.LATC7 = 1;
    __delay_ms(1000);
    LATCbits.LATC7 = 0;

    // RA4 HIGH for 1 sec 
    LATAbits.LATA4 = 1;
    __delay_ms(1000);
    LATAbits.LATA4 = 0;

    // RF4 HIGH for 2 sec
    LATFbits.LATF4 = 1;
    __delay_ms(2000);
    LATFbits.LATF4 = 0;

    // End cycle turn RA3 off
    LATAbits.LATA3 = 0;
}

// --------------------------------------------------
// Motor Cycle Loop
// --------------------------------------------------
int main(void)
{
    SYSTEM_Initialize();
    IO_Init();

    while (1)
    {
        // RD7 ACTIVE-HIGH BUTTON
        if (PORTDbits.RD7 == 1)
        {
            __delay_ms(50);   // debounce

            if (PORTDbits.RD7 == 1)
            {
                MotorSequence();

                // Wait for release (RD7 returns LOW)
                while (PORTDbits.RD7 == 1)
                {
                    __delay_ms(10);
                }

                __delay_ms(50); // release debounce
            }
        }
    }
}
