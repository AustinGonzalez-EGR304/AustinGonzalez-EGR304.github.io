#include <xc.h>
#include <stdint.h>
#include "mcc_generated_files/system/system.h"

#ifndef _XTAL_FREQ
#define _XTAL_FREQ 64000000UL
#endif

// -----------------------------------------------------------------------------
// blocking delay 
// -----------------------------------------------------------------------------
static void delay_ms_blocking(uint16_t ms)
{
    while (ms--)
    {
        __delay_ms(1);   // 1 ms per loop
    }
}

// -----------------------------------------------------------------------------
// Pin names
// -----------------------------------------------------------------------------

// Watering / reservoir control
#define TRIGGER_TIMER_PORT       PORTAbits.RA5   // RA5: timer / watering trigger

#define RequestMoisture          LATBbits.LATB3  // RB3: moisture request out
#define MoistureProcess          PORTBbits.RB0   // RB0: moisture module confirms

#define ReservoirRequest         LATBbits.LATB6  // RB6: reservoir request out
#define ReservoirProcessing      PORTFbits.RF1   // RF1: reservoir "processing" return
#define ReservoirDone            PORTBbits.RB2   // RB2: reservoir "done" / success

#define TIMEOUT_LED_LAT          LATAbits.LATA3  // RA3: timeout/error LED + fertilizer active indicator
#define PUMP_LAT                 LATFbits.LATF4  // RF4: pump output

// Onboard push button on RC1 (active LOW) -> start fertilizer sequence (FUNCTION 2)
#define RESET_BUTTON_PORT        PORTCbits.RC1

// Fertilizer motor control
#define MOTOR_REV_LAT            LATCbits.LATC7  // RC7: reverse motor (5 s)
#define MOTOR_BRAKE1_LAT         LATAbits.LATA4  // RA4: brake pulse (100 ms)
#define MOTOR_FWD_LAT            LATFbits.LATF0  // RF0: forward motor (10 s)
#define MOTOR_BRAKE2_LAT         LATFbits.LATF2  // RF2: brake pulse (100 ms)

// -----------------------------------------------------------------------------
// ADC configuration: ADCC (12-bit), Vref = VDD
// -----------------------------------------------------------------------------
#define ADC_MAX_COUNTS     4095U
#define ADC_CHANNEL_RA6    0x06U     // RA6 / AN6

// Global threshold in ADC counts, computed from a voltage in main()
static uint16_t gAnalogThreshold;

// -----------------------------------------------------------------------------
// Convert a voltage (0?VDD) into 12-bit ADC counts (0?4095)
// -----------------------------------------------------------------------------
static uint16_t VoltageToAdcCounts(float volts)
{
    const float VDD      = 5.0f;                  // supply voltage
    const float ADC_MAX  = (float)ADC_MAX_COUNTS;
    float ratio = volts / VDD;

    if (ratio < 0.0f) ratio = 0.0f;
    if (ratio > 1.0f) ratio = 1.0f;

    return (uint16_t)(ratio * ADC_MAX + 0.5f);    // round to nearest
}

static void ADCC_Init(void)
{
    // Enable ADCC
    ADCON0bits.ADON = 1;

    // Clock source = FRC (dedicated RC oscillator for ADCC)
    ADCON0bits.ADCS = 1;

    // Right-justified result (ADRESL/ADRESH form a 16-bit result)
    ADCON0bits.ADFM = 1;
}

static uint16_t ADCC_ReadValue(uint8_t channel)
{
    ADPCH = channel;
    ADCON0bits.ADGO = 1;
    while (ADCON0bits.ADGO)
    {
        ;
    }
    return (uint16_t)(((uint16_t)ADRESH << 8) | ADRESL);
}

// -----------------------------------------------------------------------------
// I/O setup
// -----------------------------------------------------------------------------
static void IO_Init(void)
{
    // --- ANSEL: set analog vs digital ---

    // PORTA
    ANSELAbits.ANSELA6 = 1;   // RA6 analog
    ANSELAbits.ANSELA5 = 0;   // RA5 digital
    ANSELAbits.ANSELA4 = 0;   // RA4 digital
    ANSELAbits.ANSELA3 = 0;   // RA3 digital

    // PORTB
    ANSELBbits.ANSELB0 = 0;
    ANSELBbits.ANSELB2 = 0;
    ANSELBbits.ANSELB3 = 0;
    ANSELBbits.ANSELB6 = 0;

    // PORTF
    ANSELFbits.ANSELF0 = 0;
    ANSELFbits.ANSELF1 = 0;
    ANSELFbits.ANSELF2 = 0;
    ANSELFbits.ANSELF4 = 0;

    // PORTC
    ANSELCbits.ANSELC7 = 0;
    ANSELCbits.ANSELC1 = 0;   // RC1 button

    // --- TRIS: 0 = output, 1 = input ---

    // Watering inputs
    TRISAbits.TRISA5 = 1;     // RA5 timer/watering trigger
    TRISBbits.TRISB0 = 1;     // RB0 moisture confirmation
    TRISBbits.TRISB2 = 1;     // RB2 reservoir "done"
    TRISAbits.TRISA6 = 1;     // RA6 analog input
    TRISFbits.TRISF1  = 1;    // RF1 reservoir "processing"

    // Watering outputs
    TRISBbits.TRISB3 = 0;     // RB3 moisture request
    TRISBbits.TRISB6 = 0;     // RB6 reservoir request
    TRISAbits.TRISA3 = 0;     // RA3 timeout LED / fertilizer active
    TRISFbits.TRISF4 = 0;     // RF4 pump

    // Button input
    TRISCbits.TRISC1 = 1;     // RC1 button

    // Fertilizer outputs
    TRISCbits.TRISC7 = 0;     // RC7 reverse motor
    TRISAbits.TRISA4 = 0;     // RA4 brake
    TRISFbits.TRISF0 = 0;     // RF0 forward motor
    TRISFbits.TRISF2 = 0;     // RF2 brake

    // Initialize outputs LOW
    RequestMoisture    = 0;
    ReservoirRequest   = 0;
    TIMEOUT_LED_LAT    = 0;
    PUMP_LAT           = 0;

    MOTOR_REV_LAT      = 0;
    MOTOR_BRAKE1_LAT   = 0;
    MOTOR_FWD_LAT      = 0;
    MOTOR_BRAKE2_LAT   = 0;
}

// -----------------------------------------------------------------------------
// System reset (currently unused, but kept for possible future use)
// -----------------------------------------------------------------------------
static void ResetSystemState(void)
{
    // Clear outputs
    RequestMoisture    = 0;
    ReservoirRequest   = 0;
    TIMEOUT_LED_LAT    = 0;
    PUMP_LAT           = 0;

    MOTOR_REV_LAT      = 0;
    MOTOR_BRAKE1_LAT   = 0;
    MOTOR_FWD_LAT      = 0;
    MOTOR_BRAKE2_LAT   = 0;
}

// -----------------------------------------------------------------------------
// FUNCTION 1: ProcessWateringSequence
//
// Runs every timer signal (RA5 rising edge).
//
// 1) Moisture request:
//    - RB3 HIGH, module does its thing, then RB0 goes LOW when done.
//
// 2) Reservoir handshake:
//    - RB6 HIGH (ReservoirRequest).
//    - Wait (<=10s) for RF1 HIGH (ReservoirProcessing).
//    - Once RF1 HIGH, wait (<=10s) for RB2 HIGH (ReservoirDone).
//    - If either times out -> blink RA3 up to 30 times.
//
// 3) Check RA6 analog vs threshold:
//    - If ADC > threshold -> soil wet enough, no pump.
//    - If ADC <= threshold -> run pump RF4 HIGH for 10s.
//
// Returns 1 on success, 0 on any error/timeout.
// -----------------------------------------------------------------------------
static int ProcessWateringSequence(void)
{
    // --- Step 1: Moisture handshake (RB3/RB0) ---
    RequestMoisture = 1;       // RB3 high: request moisture reading

    // Wait for MoistureProcess (RB0) to go LOW (or whatever your protocol is).
    // Currently you only wait AFTER reservoir sequence. Adjust as needed.

    // --- Step 2: Reservoir handshake (RB6 / RF1 / RB2) ---

    // Send reservoir request
    ReservoirRequest = 1;

    // 2a. Wait up to 10 seconds for RF1 HIGH (processing started)
    uint16_t elapsedMs = 0;
    const uint16_t timeoutMs1 = 10000;
    uint8_t processingSeen = 0;

    while (elapsedMs < timeoutMs1)
    {
        if (ReservoirProcessing != 0)   // RF1 HIGH?
        {
            processingSeen = 1;
            break;
        }
        delay_ms_blocking(10);
        elapsedMs += 10;
    }

    if (!processingSeen)
    {
        // No processing signal -> flash error LED
        int count = 0;
        while (count < 30)
        {
            TIMEOUT_LED_LAT = 1;
            delay_ms_blocking(200);
            TIMEOUT_LED_LAT = 0;
            delay_ms_blocking(200);
            count++;
        }
        ReservoirRequest = 0;
        RequestMoisture  = 0;
        return 0;
    }

    // 2b. Once RF1 is HIGH, wait up to 10 seconds for RB2 HIGH (done)
    elapsedMs = 0;
    const uint16_t timeoutMs2 = 10000;
    uint8_t doneSeen = 0;

    while (elapsedMs < timeoutMs2)
    {
        if (ReservoirDone != 0)  // RB2 HIGH?
        {
            doneSeen = 1;
            break;
        }
        delay_ms_blocking(10);
        elapsedMs += 10;
    }

    ReservoirRequest = 0;       // Clear RB6 when done

    if (!doneSeen)
    {
        // Never saw RB2 go HIGH -> flash error LED
        int count = 0;
        while (count < 30)
        {
            TIMEOUT_LED_LAT = 1;
            delay_ms_blocking(200);
            TIMEOUT_LED_LAT = 0;
            delay_ms_blocking(200);
            count++;
        }
        RequestMoisture = 0;
        return 0;
    }

    // Moisture module done? Wait for it to finish if needed.
    while (MoistureProcess != 0)
    {
        delay_ms_blocking(1);
    }

    // --- Step 3: check soil moisture via ADC on RA6 ---
    uint16_t MoistureLevel = ADCC_ReadValue(ADC_CHANNEL_RA6);
    RequestMoisture  = 0;       // Clear RB3

    if (MoistureLevel > gAnalogThreshold)
    {
        // Above threshold: soil is wet enough, no pumping.
        return 1;
    }
    else
    {
        // Below threshold: run pump on RF4 for 10 seconds
        PUMP_LAT = 1;
        uint16_t ms = 10000;
        while (ms--)
        {
            __delay_ms(1);
        }
        PUMP_LAT = 0;
    }

    return 1;
}

// -----------------------------------------------------------------------------
// FUNCTION 2: ProcessFertilizerSequence
//
// Triggered by RC1 button press (active LOW, on press edge).
//
// Behavior:
// - Turn RA3 ON for the entire fertilizer cycle.
// - Wait for pump (RF4) to be off.
// - RC7 HIGH for 5 s (reverse motor).
// - RA4 brake pulse 100 ms.
// - RF0 HIGH for 10 s (forward motor).
// - RF2 brake pulse 100 ms.
// - Turn RA3 OFF at the end.
// -----------------------------------------------------------------------------
static void ProcessFertilizerSequence(void)
{
    // Indicate fertilizer sequence active
    TIMEOUT_LED_LAT = 1;

    // Wait for RF4 to be LOW (ensure no overlap with pump)
    while (PUMP_LAT == 1)
    {
        // simple wait; add delay to avoid tight spin
        __delay_ms(1);
    }

    // Reverse motor for 5 seconds
    MOTOR_REV_LAT = 1;
    for (uint16_t ms = 0; ms < 5000; ms++)
    {
        __delay_ms(1);
    }
    MOTOR_REV_LAT = 0;

    // Brake pulse 100 ms
    MOTOR_BRAKE1_LAT = 1;
    for (uint16_t ms = 0; ms < 100; ms++)
    {
        __delay_ms(1);
    }
    MOTOR_BRAKE1_LAT = 0;

    // Forward motor for 10 seconds
    MOTOR_FWD_LAT = 1;
    for (uint16_t ms = 0; ms < 10000; ms++)
    {
        __delay_ms(1);
    }
    MOTOR_FWD_LAT = 0;

    // Brake pulse 100 ms
    MOTOR_BRAKE2_LAT = 1;
    for (uint16_t ms = 0; ms < 100; ms++)
    {
        __delay_ms(1);
    }
    MOTOR_BRAKE2_LAT = 0;

    // Fertilizer cycle complete -> turn LED off
    TIMEOUT_LED_LAT = 0;
}

// -----------------------------------------------------------------------------
// main()
//
// - RA5: "timer" / watering cycle trigger (rising edge)
//   -> runs watering sequence every timer signal.
//
// - RC1: button (active LOW). Each PRESS of RC1 starts the fertilizer sequence
//   (ProcessFertilizerSequence), with RA3 ON for the duration.
//
// ----------------------------------------------------------------------------->
void main(void)
{
    SYSTEM_Initialize();
    IO_Init();
    ADCC_Init();

    // Set your analog threshold voltage here (in volts)
    gAnalogThreshold = VoltageToAdcCounts(2.5f);

    uint8_t prevRa5       = 0;
    uint8_t prevButtonRaw = 1;   // assume button not pressed initially (RC1 idle HIGH)

    while (1)
    {
        // ---------------------------------------------------------------------
        // RC1 BUTTON: start FUNCTION 2 (fertilizer sequence)
        //
        // Button is active LOW:
        //   RESET_BUTTON_PORT == 0 -> pressed
        // Detect falling edge: previous = 1 (not pressed), now = 0 (pressed)
        // ---------------------------------------------------------------------
        uint8_t buttonRaw = RESET_BUTTON_PORT ? 1u : 0u; // 1 = not pressed, 0 = pressed (raw RC1 level)

        if ((prevButtonRaw == 1u) && (buttonRaw == 0u))
        {
            // On each press of RC1, run the fertilizer sequence once
            ProcessFertilizerSequence();
        }
        prevButtonRaw = buttonRaw;

        // ---------------------------------------------------------------------
        // Watering / timer sequence trigger on RA5 rising edge
        // ---------------------------------------------------------------------
        uint8_t ra5_now = (TRIGGER_TIMER_PORT != 0u) ? 1u : 0u;
        if (ra5_now && !prevRa5)
        {
            // Always run watering sequence on every timer pulse
            int res = ProcessWateringSequence();
            if (res == 0)
            {
                // Error path: make sure requests are dropped
                ReservoirRequest = 0;
                RequestMoisture  = 0;
            }
        }
        prevRa5 = ra5_now;

        // Small idle delay
        delay_ms_blocking(5);
    }
}
